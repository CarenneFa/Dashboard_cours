module.exports = { 
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {},
  },
  darkMode: 'class', // Active le mode sombre basé sur une classe
  plugins: [],
};
